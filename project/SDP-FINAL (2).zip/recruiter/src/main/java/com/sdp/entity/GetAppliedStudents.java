package com.sdp.entity;

import java.util.List;

public class GetAppliedStudents 
{
	public List<Student> l;

	public List<Student> getL() {
		return l;
	}

	public void setL(List<Student> l) {
		this.l = l;
	}

}
