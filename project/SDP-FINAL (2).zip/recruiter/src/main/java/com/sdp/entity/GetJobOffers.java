package com.sdp.entity;

import java.util.List;

public class GetJobOffers 
{
  private List<Job> l;

  public List<Job> getL() {
    return l;
  }

  public void setL(List<Job> l) {
    this.l = l;
  }

}