package com.sdp.entity;

import java.util.List;

public class GetJobOffers 
{
	private List<JobOffers> l;

	public List<JobOffers> getL() {
		return l;
	}

	public void setL(List<JobOffers> l) {
		this.l = l;
	}

}
