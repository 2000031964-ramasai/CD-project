package com.sdp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sdp.entity.PO;

public interface PORepository extends JpaRepository<PO, Integer>{

}
