package com.sdp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sdp.entity.Result;

public interface ResultRepo extends JpaRepository<Result, Integer>{

}
